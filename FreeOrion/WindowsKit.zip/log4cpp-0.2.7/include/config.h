/* include/config.h.  Generated automatically by configure.  */
/* include/config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 0

/* Define if you have the `ftime' function. */
#define HAVE_FTIME 1

/* Define if you have the `gettimeofday' function. */
#define HAVE_GETTIMEOFDAY 0

/* define if the compiler has int64_t */
//#define HAVE_INT64_T 

/* Define if you have the <io.h> header file. */
//#define HAVE_IO_H 1

/* Define if you have the `idsa' library (-lidsa). */
/* #undef HAVE_LIBIDSA */

/* define if the compiler implements namespaces */
#define HAVE_NAMESPACES 

/* define if the C library has snprintf */
#define HAVE_SNPRINTF 

/* define if the compiler has stringstream */
#define HAVE_SSTREAM 

/* Define if you have the `strcasecmp' function. */
#define HAVE_STRCASECMP 1

/* Define if you have the `stricmp' function. */
/* #undef HAVE_STRICMP */

/* Define if you have the `syslog' function. */
//#define HAVE_SYSLOG 1

/* Define if you have the <unistd.h> header file. */
//#define HAVE_UNISTD_H 1

/* Name of package */
#define PACKAGE "log4cpp"

/* Version number of package */
#define VERSION "0.2.7"

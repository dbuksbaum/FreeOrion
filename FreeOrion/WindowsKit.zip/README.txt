This file contains many of the files needed to build FreeOrion.  Now you need boost and DevC++ before we do anything else.  If it seems like I'm holding your hand, I am a little.  It's a lot easier for me to write a step-by-step than to answer a lot of questions later.  Please bear with me.

First, go to http://prdownloads.sourceforge.net/boost/boost_1_30_0.zip to download the file directly.  Unzip it into your root directory; it will make an extensive tree under the name boost_1_30_0.

Go to http://www.bloodshed.net/dev/devcpp.html and pick the entry under "Downloads" labeled "Dev-C++ ... with Mingw/GCC 3.2".  Once you have it, just install it like you would anything else (go ahead and install all the options, it's not very big).  As soon as you're done, open up DevC++ and choose "Check for Updates/Packages" from the "Tools" menu.  Click the check-mark in the resulting dialog to find updates and stuff.  When you see the list of packages, pick "DevC++ Critical Update", "DevC++ Crash Detection", and "SDL DevPak" (near the bottom).  Pick more if you like, but you'll need these.  It will run you through the packages in this installer app that comes up.  It has been a little flaky on me more than once, so you might need to make sure the little package icon appears for the SDL DevPak before you leave the last screen of the installer.

Use CVS to check out the FreeOrion source code files.

Put the directories "Expat-1.95.5" and "log4cpp-0.2.7" from this zip into your root directory.  Finally, take the files in the "copy-to-Dev-Cpp" directory of this zip, and put the files in C:\Dev-Cpp (or wherever you installed DevC++), just as they are in "copy-to-Dev-Cpp".  For instance, the ft2build.h file goes in C:\Dev-Cpp\include, not C:\Dev-Cpp\include\freetype2.

Place the files "SDL.dll", "SDL_image.dll", and "arial.ttf" from this zip into the FreeOrion directory (wherever you checked out the source code).

Finally, start up DevC++, open and build FreeOrion\Server.dev, FreeOrion\HumanClient.dev, then FreeOrion\AIClient.dev; everything should compile and run as-is.

Enjoy.

Zach Laine
"tzlaine"
